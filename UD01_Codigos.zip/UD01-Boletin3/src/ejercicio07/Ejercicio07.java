package ejercicio07;

import java.util.Scanner;

public class Ejercicio07 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Double precioInfantiles = 15.50;
		Double precioAdultos = 20.0;
		System.out.println("¿Cuantas entradas infantiles quiere comprar? ");
		Integer numInf = sc.nextInt();
		System.out.println("¿Cuantas entradas adultas quiere comprar? ");
		Integer numAdu = sc.nextInt();
		Double total = (numInf * precioInfantiles) + (numAdu * precioAdultos);
		if (total > 100) {
			Double descuento = total * 5 / 100;
			total = total - descuento;
		}
		System.out.println("Su precio total es: " + total + " EUR");
		sc.close();
	}
}
