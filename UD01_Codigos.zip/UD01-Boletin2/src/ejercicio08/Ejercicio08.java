package ejercicio08;

public class Ejercicio08 {
	public static void main(String[] args) {
		Double numProd=18.45;
		Double capCaja=2.5;
		System.out.println("Seran necesarias :"+(int)(Math.ceil((numProd)/capCaja))+" cajas.");
	}
}
