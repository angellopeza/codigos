package ejercicio04;

import java.util.Scanner;

public class Ejercicio04 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Para: y=ax² + bx + c \na= ");
		Integer a = sc.nextInt();
		System.out.println("b= ");
		Integer b = sc.nextInt();
		System.out.println("c= ");
		Integer c = sc.nextInt();
		System.out.println("x= ");
		Integer x = sc.nextInt();
		Integer operacion = (((x * x) * a) + (x * b) + c);
		System.out.println("Resultado: " + operacion);
		sc.close();
	}
}