package ejercicio01;

import java.util.Scanner;

public class Ejercicio01 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el numero: ");
		Double x = sc.nextDouble();
		System.out.println("El numero es: " + x);
		System.out.print("Redondeado al entero mas proximo es: ");
		System.out.printf("%.0f", x);
		sc.close();
	}
}
