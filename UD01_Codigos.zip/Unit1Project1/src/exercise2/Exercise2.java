package exercise2;

public class Exercise2 {
	public static void main(String[] args) {
		System.out.println("Hello, how are you? ");
		System.out.println("Fine thanks.");
		}
		}

//The console show you two texts, the first one show the phrase:"Hello, how are you?"
//The second one appears just under the other and sais:"Fine thanks."