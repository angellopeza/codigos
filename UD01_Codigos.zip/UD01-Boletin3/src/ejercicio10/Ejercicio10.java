package ejercicio10;

import java.util.Scanner;

public class Ejercicio10 {
	public static void main(String[] args) {
		System.out.println("Introduce el año: ");
		Scanner sc = new Scanner(System.in);
		Integer anyo = sc.nextInt();
		Integer siglo = ((anyo - 1) / 100) + 1;
		System.out.println("El año: " + anyo + " es del siglo " + siglo);
		sc.close();
	}
}
