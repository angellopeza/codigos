package ejercicio03;

public class Ejercicio03 {
	public static void main(String[] args) {
		Integer num = 8;
		Integer num2 = 3;
		Integer total = null;
		if (num % num2 == 0) {
			System.out.println("El numero es multiplo de " + num2);
		} else {
			total = num2 - (num % num2);
			System.out.println("A " + num + " hay que sumarle: " + total + " para que sea multiplo de " + num2);

		}
	}
}
