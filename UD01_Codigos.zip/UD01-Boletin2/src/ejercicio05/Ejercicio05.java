package ejercicio05;

public class Ejercicio05 {
	public static void main(String[] args) {
	Double x =6.5;
	System.out.println("Numero real: "+x);
	System.out.println("El valor absoluto de "+x+" es: "+ Math.abs(x));
	System.out.println("La raziz cuadrada de "+x+" es: "+Math.sqrt(x));
	}
}
