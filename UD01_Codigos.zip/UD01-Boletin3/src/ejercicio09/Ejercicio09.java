package ejercicio09;

import java.util.Scanner;

public class Ejercicio09 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Identificador: ");
		Integer id = sc.nextInt();
		Integer vol = id / 100;
		System.out.println("El problema " + id + " esta en el volumen: " + vol);
		sc.close();
	}
}
