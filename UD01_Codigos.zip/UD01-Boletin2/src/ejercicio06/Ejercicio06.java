package ejercicio06;

public class Ejercicio06 {
	public static void main(String[] args) {
		Integer numero = (int) (Math.random() * 6)+1;
		System.out.println("En el dado ha salido el numero: "+numero);
	}
}
