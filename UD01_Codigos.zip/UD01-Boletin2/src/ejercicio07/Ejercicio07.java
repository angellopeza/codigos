package ejercicio07;
import java.util.Random; // IA

public class Ejercicio07 {
	public static void main(String[] args) {
		int entero=(int)(Math.random()*100)+1;
		Double real=Math.random();
		Random random = new Random(); // IA 
        Boolean booleano = random.nextBoolean(); // IA
		System.out.println("Entero: "+entero+"\nReal: "+real+"\nBooleano: "+booleano );
	}
}

// El apartado de booleano no sabia como hacerlo mediante las diapositivas
// y me he apoyado en la IA entendiendolo// Importo la herramienta que me
// generara el aleatorio.