package ejercicio12;

public class Ejercicio12 {
	public static void main(String[] args) {
		Integer edad=18;
		Double entradaMenor=6.50;
		Double entradaMayor=9.50;
		Double precio = edad>=18? entradaMayor : entradaMenor;
		System.out.println(precio);
	}
}
