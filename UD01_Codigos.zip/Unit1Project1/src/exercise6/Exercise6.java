package exercise6;

public class Exercise6 {
	public static void main(String[] args) {
		System.out.println("Name: Angel");
		System.out.println("Address: C/ China\n");
		System.out.println("Telephone number: 666 22 44 88");
	}
}