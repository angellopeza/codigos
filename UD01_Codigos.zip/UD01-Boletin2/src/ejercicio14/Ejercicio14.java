package ejercicio14;

public class Ejercicio14 {
	public static void main(String[] args) {
		Integer puntos=100;
		Integer vidas =3;
		Integer puntosSuma=(puntos+=50);
		Integer puntosFinal=(puntosSuma-=20);
		Integer vidasSuma=(vidas+=1);
		Integer vidasFinal=(vidasSuma-=1);
		System.out.println("Los puntos finales son: "+puntosFinal+ "\nLas vidas finales son: "+vidasFinal);
	}
}