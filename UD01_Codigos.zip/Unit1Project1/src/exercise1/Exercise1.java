package exercise1;

public class Exercise1 {
	public static void main(String[] args) {
		System.out.print("Hello, how are you? ");
		System.out.println("Fine thanks.");
	}
}
// The console show you two texts, the first one show the phrase:"Hello, how are you?"
// The second one appears just next to the other and sais:"Fine thanks."