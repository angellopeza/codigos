package ejercicio02;

public class Ejercicio02 {
	public static void main(String[] args) {
		Integer num = 4;
		Integer total = null;
		if (num % 7 == 0) {
			System.out.println("El numero es multiplo de 7");
		} else {
			total = 7 - (num % 7);
		}
		System.out.println("A " + num + " hay que sumarle: " + total + " para que sea multiplo de 7");
	}
}
