package ejercicio09;

public class Ejercicio09 {
	public static void main(String[] args) {
		Double litAgua=18.48;
		Double capBote=2.5;
		System.out.println("Se llenarían completas :"+(int)(Math.floor((litAgua)/capBote))+" botellas.");
	}
}
