package ejercicio05;

import java.util.Scanner;

public class Ejercicio05 {
	public static void main(String[] args) {
		System.out.println("Inrtoduzca segundos: ");
		Scanner sc = new Scanner(System.in);
		Integer segundos = sc.nextInt();
		Integer horas = segundos / 3600;
		Integer segundosRestantes = segundos % 3600;
		Integer minutos = segundosRestantes / 60;
		Integer segundosFinales = segundosRestantes % 60;
		System.out.println("Total: " + horas + "h " + minutos + "m " + segundosFinales + "s");
		sc.close();
	}
}
