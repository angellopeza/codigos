package ejercicio04;

import java.util.Scanner;

public class Ejercicio04 {
	public static void main(String[] args) {
		System.out.println("Numero real: ");
		Scanner sc = new Scanner(System.in);
		Double numRe = sc.nextDouble();
		Integer numInf = (int) Math.floor(numRe);
		Integer numSup = (int) Math.ceil(numRe);
		Integer numRed = (int) Math.round(numRe);
		System.out.println("El entero inferior mas proximo es: "+numInf);
		System.out.println("El entero superior mas proximo es: "+numSup);
		System.out.println("El entero redondeado es: "+numRed);
		sc.close();
	}
}
