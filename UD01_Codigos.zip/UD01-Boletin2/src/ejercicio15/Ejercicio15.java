package ejercicio15;

public class Ejercicio15 {
	public static void main(String[] args) {
		Integer a = 2;
		Integer b = 4;
		Integer c = 6;

		Integer operacionUno = a + b * c;
		Integer operacionDos = (a + b) * c;
		System.out.println("Resultado uno: "+operacionUno+ "\nResultado dos: "+operacionDos);
	}
}

// Distinto debido a que si no hay parentesis la jerarquia de las operaciones
// nos obliga a multiplicar antes que ahcer la suma/resta
// en cambio si hay parentesis nos obliga a realizar el calculo de su interior antes.