package ejercicio13;

public class Ejercicio13 {
	public static void main(String[] args) {
		Double dinero= 22.30;
		int euroEntero= (int)Math.floor(dinero);
		Double centimosRedondeados= (double)(Math.round(dinero-euroEntero));
		System.out.println("Euros enteros: "+euroEntero+ "\nCentimos redondeados: "+centimosRedondeados);
	}
}
