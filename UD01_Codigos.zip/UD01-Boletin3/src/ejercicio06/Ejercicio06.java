package ejercicio06;

public class Ejercicio06 {
	public static void main(String[] args) {
		Double mm = 500.0;
		Double c = 6.0;
		Double m = 1.0;

		Double total = (mm / 10) + c + (m * 100);
		System.out.println("La medida total en cm son: " + total);
	}
}
