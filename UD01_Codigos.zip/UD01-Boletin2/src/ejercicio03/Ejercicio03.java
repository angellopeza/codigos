package ejercicio03;

import java.util.Scanner;

public class Ejercicio03 {
	public static void main(String[] args) {
		System.out.println("Precio inicial: ");
		Scanner sc = new Scanner(System.in);
		Double precioInicial = sc.nextDouble();
		final Integer IVA = 21;
		final Integer DESCUENTO = 15;
		Double precioFinalIva = (precioInicial+(precioInicial*IVA/100));
		Double precioFinal = (precioFinalIva-(precioFinalIva*DESCUENTO/100));
		Double precioFinalRedondeado= (double) Math.round(precioFinal*100.0)/100.0;
		System.out.println("El precio final es: "+precioFinalRedondeado+ " euros.");
		sc.close();
	}
}
