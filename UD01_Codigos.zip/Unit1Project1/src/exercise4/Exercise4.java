package exercise4;

public class Exercise4 {
	public static void main(String[] args) {
		System.out.println("I want this program to compile");
		
		}
}


// you have to put the text between <<"">>
// put an ";" at the final of the syso
// and write "System" instead of "system".