package ejercicio08;

import java.util.Scanner;

public class Ejercicio08 {
	public static void main(String[] args) {
		System.out.println("Longitud en metros: ");
		Scanner sc = new Scanner(System.in);
		Double metros = sc.nextDouble();
		Double centimetros = metros * 100;
		Integer centimetrosEnteros = (int) (centimetros * 100) / 100;
		System.out.println("La longitud total fue: " + centimetrosEnteros + "cm");
		sc.close();
	}
}
