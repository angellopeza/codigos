package ejercicio01;

import java.util.Scanner;

public class Ejercicio01 {
	public static void main(String[] args) {
		System.out.println("Introduzca la base: ");
		Scanner sc = new Scanner(System.in);
		Double base =sc.nextDouble();
		System.out.println("Introduzaca la altura: ");
		Double altura= sc.nextDouble();
		Double perimetro = 2*(base+altura);
		Double area = base*altura;
		System.out.println("El perimetro del rectangulo es : "+perimetro);
		System.out.println("El area del rectangulo es: "+area);
		sc.close();
	}
}
