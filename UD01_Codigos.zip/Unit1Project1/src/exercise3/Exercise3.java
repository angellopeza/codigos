package exercise3;

public class Exercise3 {
	public static void main(String[] args) {
		System.out.println("1 + 2 " + "+ 3" + " = 6");
		}
		}

// After the execution, this code shows you the literal operation "1 + 2 + 3 = 6".