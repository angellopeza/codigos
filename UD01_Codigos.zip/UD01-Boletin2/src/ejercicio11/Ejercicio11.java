package ejercicio11;

public class Ejercicio11 {
	public static void main(String[] args) {
		Boolean permiso=true;
		Boolean sancion=false;
		Integer edad=18;
		Boolean puede= edad>=18 && permiso==true && sancion==false?true:false;
		System.out.println("¿puede alquilarlo?: "+puede);
	}
}
